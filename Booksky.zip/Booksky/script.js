var add=document.querySelector(".addbutton")
var over=document.querySelector(".overlay")
var pop=document.querySelector(".popup")

var cancelpop=document.querySelector("#cancel")




add.addEventListener("click",function(){
    over.style.display="block"
    pop.style.display="block"
})

cancelpop.addEventListener("click",function(event){
    event.preventDefault()
    over.style.display="none"
    pop.style.display="none"
})

var book=document.querySelector(".booksection")
var addbook=document.getElementById("add-book")
var title=document.getElementById("book-title-input")
var author=document.getElementById("book-author-input")
var description=document.getElementById("description-input")

addbook.addEventListener("click",function(event){
    event.preventDefault()
    var div=document.createElement("div")
    div.setAttribute("class","one")
    div.innerHTML=`<h2>${title.value}</h2>
                  <h5>${author.value}</h5>
                  <p>${description.value}</p>
                  <button onclick='deletebook(event)'>Delete</button>`
    book.append(div)
    over.style.display="none"
    pop.style.display="none"

})

function deletebook(event){
    event.target.parentElement.remove()
}